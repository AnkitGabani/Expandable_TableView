//
//  ViewEx.swift
//  aptbl
//
//  Created by SMIT KUKADIYA on 18/09/20.
//  Copyright © 2020 SMIT KUKADIYA. All rights reserved.
//

import UIKit

class ViewEx: UIView {

    @IBOutlet weak var txtname: UILabel!
    
}
