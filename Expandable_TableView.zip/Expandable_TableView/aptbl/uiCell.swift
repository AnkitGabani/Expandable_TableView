//
//  uiCell.swift
//  aptbl
//
//  Created by SMIT KUKADIYA on 18/09/20.
//  Copyright © 2020 SMIT KUKADIYA. All rights reserved.
//

import UIKit

class uiCell: UITableViewCell {

    @IBOutlet weak var uiview: UIView!
    @IBOutlet weak var lblname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.uiview.layer.cornerRadius = 10
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
