//
//  ViewController.swift
//  aptbl
//
//  Created by SMIT KUKADIYA on 18/09/20.
//  Copyright © 2020 SMIT KUKADIYA. All rights reserved.
//

import UIKit



//struct cellData {
//    var opened = Bool()
//    var title = String()
//}

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource, UIGestureRecognizerDelegate {
    
    
    
    @IBOutlet weak var tblview: UITableView!
    
    var arrtbl = ["Tent (And Footprint, Stakes)","Headlamps or Flashlights","Camp Chairs","Camp Table (If No Picnic Table)","Tablecloth and Clips (Or Tape)","Lantern"]
    
    var arrtbl1 = ["Tent (And Footprint, Stakes)"]
    
    var arrname = ["💊 Health & Hygiene","🏕 Shelter + 🛏️ Bedding","🍳 Cooking at Camp","🔨 Tools & Repairs","🛒 Things We Need to Shop"]
    var arrContaianObjc = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tblview.delegate = self
        tblview.dataSource = self
        
        self.tblview.tableFooterView = UIView()
        
        let headerNib = UINib.init(nibName: "ViewEx", bundle: Bundle.main)
        tblview.register(headerNib, forHeaderFooterViewReuseIdentifier: "ViewEx")
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrname.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // 6 Change the number of row in section as per your uses
        
        if arrContaianObjc.contains(section){
            
            
            if section == 0{
               return  arrtbl.count
            } else if section == 1{
               return arrtbl.count
            } else if section == 2{
                return arrtbl.count
            } else if section == 3{
                return arrtbl.count
            } else {
                return arrtbl.count
            }
            
        }
        else{
            return 0
        }
      
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "uiCell", for: indexPath) as! uiCell
        
        if indexPath.section == 0{
            cell.lblname.text = "\(arrtbl[indexPath.row])"
        } else if indexPath.section == 1{
            cell.lblname.text = "\(arrtbl[indexPath.row])"
        } else if indexPath.section == 2{
            cell.lblname.text = "\(arrtbl[indexPath.row])"
        } else if indexPath.section == 3{
            cell.lblname.text = "\(arrtbl[indexPath.row])"
        } else {
            cell.lblname.text = "\(arrtbl[indexPath.row])"
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        
        let headerView = Bundle.main.loadNibNamed("ViewEx", owner: self, options: [:])?.first as! ViewEx
        
        //   let tap = UITapGestureRecognizer(target: self, action: #selector(tapSection(sender:)))
        //   tap.delegate = self
        //   headerView.tag = section
        //   headerView.addGestureRecognizer(tap)
        
        if arrContaianObjc.contains(section){
            headerView.imgArrow.image = UIImage(named: "ic_down")
        }
        else
        {
            headerView.imgArrow.image = UIImage(named: "ic_right")
        }
        
        
        headerView.txtname.text = "\(arrname[section])"
        
        let button = UIButton(type: .custom)
        button.frame = headerView.bounds
        button.tag = section // Assign section tag to this button
        button.addTarget(self, action: #selector(tapSection(sender:)), for: .touchUpInside)
      //  button.setTitle("Section: \(section)", for: .normal)
        headerView.addSubview(button)//
        
        return headerView
        
    }
    
    @objc func tapSection(sender: UIButton) {
        
        let section = sender.tag
        
        //        if arrContaianObjc.count > 0{
        //
        //            let openSection = arrContaianObjc.firstObject as! Int
        //
        //            arrContaianObjc.remove(openSection)
        //             self.tblview.beginUpdates()
        //            for index in 0..<arrtbl.count
        //                     {
        //                        let indexPath = IndexPath.init(row: index, section: openSection)
        //                        self.tblview.deleteRows(at: [indexPath], with: .none)
        //
        //                     }
        //                        self.tblview.endUpdates()
        //
        //
        //        }
        
        
        if arrContaianObjc.contains(section){
            
            arrContaianObjc.remove(section)
            
            self.tblview.beginUpdates()
            
            for index in 0..<arrtbl.count
            {
                let indexPath = IndexPath.init(row: index, section: section)
                self.tblview.deleteRows(at: [indexPath], with: .none)
                
            }
            
            self.tblview.endUpdates()
            
        } else{
            
            arrContaianObjc.add(section)
            
            self.tblview.beginUpdates()
            
            for index in 0..<arrtbl.count
            {
                let indexPath = IndexPath.init(row: index, section: section)
                self.tblview.insertRows(at: [indexPath], with: .none)
                
            }
            
            self.tblview.endUpdates()
            
            
        }
        
        tblview.reloadData()
        
    }
    
    
}

